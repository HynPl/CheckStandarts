# CheckStandarts
Plug-in pro Revit 2023 ke kontrole zákonů, předpisů, vyhlášek, norem, doporučením v České Republice
Verze: 0.1

## Popis instalace
1, Vyextrahovat soubor do složky "C:\ProgramData\Autodesk\Revit\Addins\2023\"
Tzn. že nové soubory budou umístěné toť...
C:\ProgramData\Autodesk\Revit\Addins\2023\RevitStairsCheck.addin
C:\ProgramData\Autodesk\Revit\Addins\2023\CheckStandarts\CheckStandarts.dll

Version: 0.1
Plug-in for Revit 2023 to check laws, standarts, regulation in Czech republic

## How to install
1, Extractfiles to folder "C:\ProgramData\Autodesk\Revit\Addins\2023\"
That means new files will be appeard in...
C:\ProgramData\Autodesk\Revit\Addins\2023\RevitStairsCheck.addin
C:\ProgramData\Autodesk\Revit\Addins\2023\CheckStandarts\CheckStandarts.dll